from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional, Union
from unittest.mock import patch

import numpy as np
from faster_whisper import WhisperModel
import faster_whisper.utils as faster_whisper_utils

from .diarization import Turn, assign_speaker


@dataclass
class Segment:
    start: float
    end: float
    text: str
    speaker: Optional[str] = None


def load_model(model_size: str = "small", device: str = "auto", compute_type: str = "default") -> WhisperModel:
    with patch.object(faster_whisper_utils, "disabled_tqdm", faster_whisper_utils.tqdm):
        return WhisperModel(model_size, device=device, compute_type=compute_type)


def transcribe_file(
    model: WhisperModel,
    source: Union[Path, np.ndarray],
    language: Optional[str] = None,
    vad: bool = True,
    on_segment: Optional[Callable[[Segment], None]] = None,
    speaker_turns: Optional[list[Turn]] = None,
) -> tuple[list[Segment], str]:
    """Return the segments and the detected (or forced) language."""
    audio = str(source) if isinstance(source, Path) else source
    raw_segments, info = model.transcribe(audio, language=language, vad_filter=vad, beam_size=5)
    segments = []
    for s in raw_segments:
        seg = Segment(start=s.start, end=s.end, text=s.text.strip())
        if speaker_turns:
            seg.speaker = assign_speaker(seg.start, seg.end, speaker_turns)
        segments.append(seg)
        if on_segment:
            on_segment(seg)
    return segments, info.language
