import os
from typing import Optional

import numpy as np

SAMPLE_RATE = 16000
DEFAULT_MODEL = "pyannote/speaker-diarization-3.1"
DEFAULT_EMBEDDING_MODEL = "pyannote/wespeaker-voxceleb-resnet34-LM"

Turn = tuple[float, float, str]


def _from_pretrained(cls, name: str, hf_token: Optional[str]):
    token = hf_token or os.environ.get("HF_TOKEN") or None
    try:
        obj = cls.from_pretrained(name, token=token)
    except TypeError:  # pyannote.audio 3.x
        obj = cls.from_pretrained(name, use_auth_token=token)
    if obj is None:
        raise RuntimeError(
            f"Impossible de charger '{name}'. Acceptez les conditions du modèle sur huggingface.co "
            "et fournissez un token via --hf-token ou la variable HF_TOKEN."
        )
    return obj


def _import_pyannote():
    try:
        import torch
        import pyannote.audio
    except ImportError as e:
        raise RuntimeError("Diarisation indisponible : installez-la avec  pip install -e .[diarization]") from e
    return torch, pyannote.audio


def _device(torch):
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def diarize(
    audio: np.ndarray,
    hf_token: Optional[str] = None,
    model: str = DEFAULT_MODEL,
    num_speakers: Optional[int] = None,
) -> list[Turn]:
    """Diarize 16 kHz mono audio and return (start, end, speaker_label) turns."""
    torch, pa = _import_pyannote()
    pipeline = _from_pretrained(pa.Pipeline, model, hf_token)
    pipeline.to(_device(torch))

    kwargs = {"num_speakers": num_speakers} if num_speakers else {}
    # In-memory waveform avoids the need for a system ffmpeg.
    output = pipeline({"waveform": torch.from_numpy(audio).unsqueeze(0), "sample_rate": SAMPLE_RATE}, **kwargs)
    annotation = getattr(output, "speaker_diarization", output)  # pyannote 4.x wraps the annotation
    return [(t.start, t.end, spk) for t, _, spk in annotation.itertracks(yield_label=True)]


class SpeakerTracker:
    """Online speaker identification: compares each utterance's voice embedding to known speakers."""

    def __init__(self, hf_token: Optional[str] = None, model: str = DEFAULT_EMBEDDING_MODEL, threshold: float = 0.5):
        self._torch, pa = _import_pyannote()
        embedding_model = _from_pretrained(pa.Model, model, hf_token)
        self._inference = pa.Inference(embedding_model, window="whole", device=_device(self._torch))
        self.threshold = threshold
        self._centroids: list[np.ndarray] = []
        self._counts: list[int] = []

    def identify(self, audio: np.ndarray) -> str:
        waveform = {"waveform": self._torch.from_numpy(audio).unsqueeze(0), "sample_rate": SAMPLE_RATE}
        emb = np.asarray(self._inference(waveform), dtype=np.float32).reshape(-1)
        emb /= np.linalg.norm(emb) + 1e-9

        if self._centroids:
            sims = [float(c @ emb) for c in self._centroids]
            best = int(np.argmax(sims))
            if sims[best] >= self.threshold:
                n = self._counts[best]
                c = self._centroids[best] * n + emb
                self._centroids[best] = c / (np.linalg.norm(c) + 1e-9)
                self._counts[best] = n + 1
                return f"SPEAKER_{best:02d}"

        self._centroids.append(emb)
        self._counts.append(1)
        return f"SPEAKER_{len(self._centroids) - 1:02d}"


def assign_speaker(start: float, end: float, turns: list[Turn]) -> Optional[str]:
    if not turns:
        return None
    overlaps: dict[str, float] = {}
    for s, e, spk in turns:
        overlap = min(end, e) - max(start, s)
        if overlap > 0:
            overlaps[spk] = overlaps.get(spk, 0.0) + overlap
    if overlaps:
        return max(overlaps, key=overlaps.get)
    return min(turns, key=lambda t: min(abs(start - t[1]), abs(end - t[0])))[2]
