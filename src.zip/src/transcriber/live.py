import queue
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

import av
import numpy as np
from faster_whisper import WhisperModel

from .core import Segment
from .writers import write_outputs

SAMPLE_RATE = 16000
BLOCK_S = 0.1  # capture read size
FRAME = 480  # 30 ms analysis frame
MIN_EMBEDDING_S = 1.0  # shorter utterances give unreliable voice embeddings


@dataclass
class Utterance:
    source: str
    start: float
    audio: np.ndarray


class Segmenter:
    """Splits a continuous stream into utterances using energy with an adaptive noise floor."""

    def __init__(self, source: str, out: "queue.Queue[Utterance]", silence_s=0.7, max_s=15.0, min_s=0.4):
        self.source, self.out = source, out
        self.silence_s = silence_s
        self.silence_frames = int(silence_s * SAMPLE_RATE / FRAME)
        self.max_frames = int(max_s * SAMPLE_RATE / FRAME)
        self.min_frames = int(min_s * SAMPLE_RATE / FRAME)
        self.noise = 1e-3
        self.pre: deque = deque(maxlen=10)  # 300 ms pre-roll so word onsets aren't cut
        self._reset()

    def _reset(self):
        self.frames: list[np.ndarray] = []
        self.start = None
        self.silence = 0

    def feed(self, block: np.ndarray, block_start: float) -> None:
        for i in range(0, len(block) - FRAME + 1, FRAME):
            frame = block[i:i + FRAME]
            rms = float(np.sqrt(np.mean(frame ** 2)))
            speech = rms > max(self.noise * 3, 0.005)
            self.noise += (0.001 if speech else 0.05) * (rms - self.noise)

            if self.start is None:
                if speech:
                    self.start = block_start + i / SAMPLE_RATE - len(self.pre) * FRAME / SAMPLE_RATE
                    self.frames = [*self.pre, frame]
                else:
                    self.pre.append(frame)
                continue

            self.frames.append(frame)
            self.silence = 0 if speech else self.silence + 1
            if self.silence >= self.silence_frames or len(self.frames) >= self.max_frames:
                self.flush()

    def flush(self) -> None:
        if self.start is not None and len(self.frames) - self.silence >= self.min_frames:
            self.out.put(Utterance(self.source, self.start, np.concatenate(self.frames)))
        self.pre.clear()
        self._reset()


def _capture(name: str, pa, device: dict, seg: Segmenter, stop: threading.Event, t0: float) -> None:
    import pyaudiowpatch as pyaudio

    rate, channels = int(device["defaultSampleRate"]), device["maxInputChannels"]
    block = int(rate * BLOCK_S)
    resampler = av.AudioResampler(format="flt", layout="mono", rate=SAMPLE_RATE)
    stream = None
    try:
        stream = pa.open(format=pyaudio.paFloat32, channels=channels, rate=rate, input=True,
                         input_device_index=device["index"], frames_per_buffer=block)
        last_data = time.monotonic()
        while not stop.is_set():
            if stream.get_read_available() < block:
                # Loopback delivers no data while nothing plays: close any pending utterance.
                if seg.start is not None and time.monotonic() - last_data > seg.silence_s:
                    seg.flush()
                time.sleep(0.02)
                continue
            raw = np.frombuffer(stream.read(block, exception_on_overflow=False), dtype=np.float32)
            last_data = time.monotonic()
            frame = av.AudioFrame.from_ndarray(raw.reshape(-1, channels).mean(axis=1)[None, :], format="flt", layout="mono")
            frame.sample_rate = rate
            out = [f.to_ndarray().reshape(-1) for f in resampler.resample(frame)]
            if out:
                audio = np.concatenate(out).astype(np.float32)
                seg.feed(audio, last_data - t0 - len(audio) / SAMPLE_RATE)
    except Exception as e:  # noqa: BLE001 - report device errors without killing the session
        print(f"\n[{name}] erreur de capture : {e!r}", file=sys.stderr)
    finally:
        if stream is not None:
            stream.close()
        seg.flush()


def _open_sources(pa, source: str) -> list[tuple[str, dict]]:
    import pyaudiowpatch as pyaudio

    sources = []
    if source in ("mic", "both"):
        wasapi = pa.get_host_api_info_by_type(pyaudio.paWASAPI)
        sources.append(("micro", pa.get_device_info_by_index(wasapi["defaultInputDevice"])))
    if source in ("system", "both"):
        sources.append(("système", pa.get_default_wasapi_loopback()))
    return sources


def run_live(model: WhisperModel, args, formats: list[str], make_callback: Callable) -> int:
    tracker = None
    if args.diarize:
        from .diarization import SpeakerTracker

        print("Chargement du modèle d'empreintes vocales...")
        try:
            tracker = SpeakerTracker(args.hf_token, threshold=args.speaker_threshold)
        except RuntimeError as e:
            print(e, file=sys.stderr)
            return 1

    names: dict[str, str] = {}
    interactive = args.diarize and not args.no_prompt and sys.stdin.isatty()
    on_segment = make_callback(names, interactive)
    last_speaker: dict[str, str] = {}
    segments: list[Segment] = []

    def handle(utt: Utterance, callback) -> None:
        raw, _ = model.transcribe(
            utt.audio, language=args.language, vad_filter=not args.no_vad,
            beam_size=5, condition_on_previous_text=False,
        )
        text = " ".join(s.text.strip() for s in raw).strip()
        if not text:
            return
        speaker = None
        if tracker:
            if len(utt.audio) >= MIN_EMBEDDING_S * SAMPLE_RATE or utt.source not in last_speaker:
                speaker = tracker.identify(utt.audio)
            else:
                speaker = last_speaker[utt.source]
            last_speaker[utt.source] = speaker
        seg = Segment(utt.start, utt.start + len(utt.audio) / SAMPLE_RATE, text, speaker)
        segments.append(seg)
        callback(seg)

    utterances: "queue.Queue[Utterance]" = queue.Queue()
    stop = threading.Event()
    t0 = time.monotonic()
    started = datetime.now()
    import pyaudiowpatch as pyaudio

    pa = pyaudio.PyAudio()
    sources = _open_sources(pa, args.source)
    threads = [
        threading.Thread(target=_capture, args=(name, pa, dev, Segmenter(name, utterances), stop, t0), daemon=True)
        for name, dev in sources
    ]
    for t in threads:
        t.start()
    devices = ", ".join(f"{n} : {d['name']}" for n, d in sources)
    print(f"Écoute en cours ({devices}). Ctrl+C pour arrêter.\n")

    try:
        while any(t.is_alive() for t in threads) or not utterances.empty():
            try:
                handle(utterances.get(timeout=0.3), on_segment)
            except queue.Empty:
                pass
    except KeyboardInterrupt:
        print("\nArrêt demandé, finalisation...")

    stop.set()
    for t in threads:
        t.join(timeout=3)
    pa.terminate()
    final_callback = make_callback(names, False)
    while not utterances.empty():
        handle(utterances.get_nowait(), final_callback)

    if not segments:
        print("Aucune parole détectée, rien n'a été enregistré.")
        return 0

    segments.sort(key=lambda s: s.start)
    for seg in segments:
        if seg.speaker:
            seg.speaker = names.get(seg.speaker, seg.speaker)
    out_dir = args.output_dir or Path("transcripts")
    for written in write_outputs(segments, Path(f"live_{started:%Y%m%d_%H%M%S}"), out_dir, formats):
        print(f"-> {written}")
    return 0
