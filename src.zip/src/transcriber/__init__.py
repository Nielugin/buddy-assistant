import os
from pathlib import Path

import truststore
from dotenv import find_dotenv, load_dotenv

# Trust the OS certificate store, required behind corporate TLS-inspecting proxies.
truststore.inject_into_ssl()

# Must run before huggingface_hub is imported, as it reads HF_* variables at import time.
load_dotenv(find_dotenv(usecwd=True))
load_dotenv(Path(__file__).resolve().parents[2] / ".env")
# Windows without Developer Mode has no symlinks; the HF cache still works.
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

from .core import Segment, transcribe_file  # noqa: E402

__all__ = ["Segment", "transcribe_file"]
