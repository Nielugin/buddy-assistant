import argparse
import sys
from pathlib import Path

from faster_whisper import decode_audio

from .core import Segment, load_model, transcribe_file
from .diarization import DEFAULT_MODEL, SAMPLE_RATE, diarize
from .writers import WRITERS, write_outputs


def ask_speaker_name(seg: Segment) -> str:
    print(f"\n>>> Nouvel intervenant détecté ({seg.speaker}) à {seg.start:.1f}s :")
    print(f"    « {seg.text} »")
    try:
        name = input(f"    Qui est-ce ? (Entrée pour garder '{seg.speaker}') : ").strip()
    except EOFError:
        name = ""
    return name or seg.speaker


def make_segment_callback(names: dict[str, str], interactive: bool, quiet: bool):
    def on_segment(seg: Segment) -> None:
        if seg.speaker and seg.speaker not in names:
            names[seg.speaker] = ask_speaker_name(seg) if interactive else seg.speaker
        if not quiet:
            who = f" {names[seg.speaker]} :" if seg.speaker else ""
            print(f"[{seg.start:7.2f} -> {seg.end:7.2f}]{who} {seg.text}")
    return on_segment


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="transcribe", description="Transcription audio/vidéo en local (faster-whisper).")
    p.add_argument("files", nargs="*", type=Path, help="Fichiers audio/vidéo à transcrire (sauf en mode --live)")
    p.add_argument("-m", "--model", default="small",
                   help="Modèle Whisper : tiny, base, small, medium, large-v3, turbo... (défaut: small)")
    p.add_argument("-l", "--language", default=None, help="Code langue (ex: fr, en). Auto-détection si absent")
    p.add_argument("-f", "--formats", default="txt,srt",
                   help=f"Formats de sortie séparés par des virgules parmi {','.join(WRITERS)} (défaut: txt,srt)")
    p.add_argument("-o", "--output-dir", type=Path, default=None,
                   help="Dossier de sortie (défaut: dossier du fichier source)")
    p.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"], help="Périphérique de calcul")
    p.add_argument("--compute-type", default="default",
                   help="Type de calcul : default, int8, float16, int8_float16... (défaut: default)")
    p.add_argument("--no-vad", action="store_true", help="Désactive le filtre de détection de voix (VAD)")
    p.add_argument("-q", "--quiet", action="store_true", help="N'affiche pas les segments en direct")
    d = p.add_argument_group("diarisation (identification des intervenants)")
    d.add_argument("-d", "--diarize", action="store_true", help="Active l'identification des intervenants")
    d.add_argument("--num-speakers", type=int, default=None, help="Nombre d'intervenants, si connu")
    d.add_argument("--hf-token", default=None,
                   help="Token Hugging Face (sinon variable d'environnement HF_TOKEN)")
    d.add_argument("--diarization-model", default=DEFAULT_MODEL, help=f"Modèle pyannote (défaut: {DEFAULT_MODEL})")
    d.add_argument("--no-prompt", action="store_true",
                   help="Ne demande pas le nom des intervenants (garde SPEAKER_00, ...)")
    lv = p.add_argument_group("mode live (transcription en direct)")
    lv.add_argument("--live", action="store_true", help="Transcrit en direct le micro et/ou le son du PC")
    lv.add_argument("--source", default="both", choices=["mic", "system", "both"],
                    help="Audio capturé : micro, son du PC (Teams...) ou les deux (défaut: both)")
    lv.add_argument("--speaker-threshold", type=float, default=0.5,
                    help="Seuil de similarité vocale (0-1) : plus haut = plus de nouveaux intervenants (défaut: 0.5)")
    args = p.parse_args(argv)
    if args.live and args.files:
        p.error("--live ne prend pas de fichier en argument")
    if not args.live and not args.files:
        p.error("indiquez au moins un fichier, ou utilisez --live")
    return args


def main(argv=None) -> int:
    args = parse_args(argv)

    formats = [f.strip().lower() for f in args.formats.split(",") if f.strip()]
    unknown = set(formats) - set(WRITERS)
    if unknown:
        print(f"Format(s) inconnu(s) : {', '.join(sorted(unknown))}", file=sys.stderr)
        return 2

    missing = [f for f in args.files if not f.is_file()]
    if missing:
        for f in missing:
            print(f"Fichier introuvable : {f}", file=sys.stderr)
        return 1

    print(f"Chargement du modèle '{args.model}' (le premier lancement le télécharge)...")
    model = load_model(args.model, args.device, args.compute_type)

    if args.live:
        from .live import run_live

        return run_live(model, args, formats, lambda names, inter: make_segment_callback(names, inter, args.quiet))

    interactive = args.diarize and not args.no_prompt and sys.stdin.isatty()

    for path in args.files:
        print(f"\n=== {path.name} ===")
        names: dict[str, str] = {}
        on_segment = make_segment_callback(names, interactive, args.quiet)

        source, turns = path, None
        if args.diarize:
            print("Diarisation en cours (identification des intervenants)...")
            source = decode_audio(str(path), sampling_rate=SAMPLE_RATE)
            try:
                turns = diarize(source, args.hf_token, args.diarization_model, args.num_speakers)
            except RuntimeError as e:
                print(e, file=sys.stderr)
                return 1
            print(f"{len({t[2] for t in turns})} intervenant(s) détecté(s). Transcription...")

        segments, lang = transcribe_file(
            model, source, args.language, vad=not args.no_vad, on_segment=on_segment, speaker_turns=turns
        )
        for seg in segments:
            if seg.speaker:
                seg.speaker = names.get(seg.speaker, seg.speaker)
        out_dir = args.output_dir or path.parent
        for written in write_outputs(segments, path, out_dir, formats):
            print(f"-> {written}")
        print(f"Langue : {lang} | {len(segments)} segments")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
