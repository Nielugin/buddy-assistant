@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\activate.bat" (
    echo Creation de l'environnement virtuel...
    py -m venv .venv
    if errorlevel 1 (
        echo Impossible de creer .venv. Verifiez que Python est installe et que la commande py est disponible.
        pause
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"
if errorlevel 1 (
    echo Impossible d'activer l'environnement virtuel.
    pause
    exit /b 1
)

echo Installation et build du projet...
python -m pip install -e .
.\.venv\Scripts\python.exe -m pip install -e ".[diarization]

if errorlevel 1 (
    echo Echec de l'installation ou du build du projet.
    pause
    exit /b 1
)

echo Lancement de la transcription live...
transcribe --live --source both -d
set "exit_code=%ERRORLEVEL%"
if not "%exit_code%"=="0" echo La transcription s'est terminee avec le code %exit_code%.
pause
exit /b %exit_code%
