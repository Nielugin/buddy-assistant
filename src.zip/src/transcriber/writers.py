import json
from pathlib import Path

from .core import Segment


def _timestamp(seconds: float, sep: str) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


def to_txt(segments: list[Segment]) -> str:
    if not any(s.speaker for s in segments):
        return "\n".join(s.text for s in segments) + "\n"
    # Merge consecutive segments of the same speaker into one paragraph.
    paragraphs: list[list] = []
    for s in segments:
        if paragraphs and paragraphs[-1][0] == s.speaker:
            paragraphs[-1][1].append(s.text)
        else:
            paragraphs.append([s.speaker, [s.text]])
    return "\n\n".join(f"{spk or '?'} : {' '.join(texts)}" for spk, texts in paragraphs) + "\n"


def to_srt(segments: list[Segment]) -> str:
    blocks = [
        f"{i}\n{_timestamp(s.start, ',')} --> {_timestamp(s.end, ',')}\n"
        f"{f'[{s.speaker}] ' if s.speaker else ''}{s.text}\n"
        for i, s in enumerate(segments, 1)
    ]
    return "\n".join(blocks)


def to_vtt(segments: list[Segment]) -> str:
    blocks = [
        f"{_timestamp(s.start, '.')} --> {_timestamp(s.end, '.')}\n"
        f"{f'<v {s.speaker}>' if s.speaker else ''}{s.text}\n"
        for s in segments
    ]
    return "WEBVTT\n\n" + "\n".join(blocks)


def to_json(segments: list[Segment]) -> str:
    data = [{"start": s.start, "end": s.end, "speaker": s.speaker, "text": s.text} for s in segments]
    return json.dumps(data, ensure_ascii=False, indent=2)


WRITERS = {"txt": to_txt, "srt": to_srt, "vtt": to_vtt, "json": to_json}


def write_outputs(segments: list[Segment], source: Path, out_dir: Path, formats: list[str]) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for fmt in formats:
        target = out_dir / f"{source.stem}.{fmt}"
        target.write_text(WRITERS[fmt](segments), encoding="utf-8")
        written.append(target)
    return written
