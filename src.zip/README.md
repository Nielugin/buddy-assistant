# Local Transcriber – Configuration du token Hugging Face

La diarisation (`-d`) repose sur les modèles **pyannote**, hébergés sur Hugging Face. Ces modèles sont en accès restreint (« gated ») : il faut un compte, accepter leurs conditions et fournir un token **une seule fois** pour les télécharger. Ensuite, ils sont mis en cache et **tout s'exécute en local**, sans envoyer l'audio à l'extérieur.

## Mode live (Windows)

Après avoir activé l'environnement virtuel, lancez la transcription en direct :

```powershell
transcribe --live
```

Par défaut, le programme écoute à la fois le microphone et le son du PC. Pour choisir une source :

```powershell
transcribe --live --source mic      # microphone uniquement
transcribe --live --source system   # son du PC uniquement (Teams, par exemple)
transcribe --live --source both     # microphone et son du PC (défaut)
```

Les segments transcrits s'affichent au fur et à mesure. Appuyez sur **Ctrl+C** pour arrêter et enregistrer les transcriptions en `.txt` et `.srt` dans `transcripts/` (ou dans le dossier indiqué avec `-o`).

Pour identifier les intervenants, ajoutez `-d` :

```powershell
transcribe --live -d
```

La diarisation nécessite un token Hugging Face ; consultez la configuration ci-dessous.

## 1. Créer un compte Hugging Face

Créez un compte sur <https://huggingface.co/join> (gratuit), ou connectez-vous si vous en avez déjà un.

## 2. Accepter les conditions des modèles

Connecté à votre compte, ouvrez chacune des pages ci-dessous, remplissez le formulaire et cliquez sur **« Agree and access repository »** :

- <https://huggingface.co/pyannote/speaker-diarization-3.1>
- <https://huggingface.co/pyannote/segmentation-3.0>

> Si vous utilisez un autre modèle avec `--diarization-model`, acceptez aussi ses conditions.

## 3. Générer un token

1. Allez dans **Settings → Access Tokens** : <https://huggingface.co/settings/tokens>
2. Cliquez sur **« Create new token »**.
3. Type : **Read** (lecture seule, suffisant).
4. Donnez-lui un nom (ex. `local-transcriber`), puis copiez le token (`hf_...`).

## 4. Configurer le token

Choisissez **une** des méthodes suivantes.

### Option A – Fichier `.env` (recommandée)

Ouvrez le fichier `.env` à la racine du projet (créez-le à partir de `.env.example` s'il n'existe pas) et renseignez le token :

```dotenv
HF_TOKEN=hf_votre_token
```

Il est chargé automatiquement à chaque lancement de `transcribe` (d'abord le `.env` du dossier courant, puis celui du projet). Une variable déjà définie dans le système reste prioritaire.

Variables optionnelles du `.env` :

| Variable | Rôle |
|---|---|
| `HF_HOME` | Dossier du cache des modèles. Conseillé hors OneDrive (ex. `C:\hf-cache`) pour éviter de synchroniser plusieurs Go |
| `HTTPS_PROXY` | Proxy d'entreprise pour le téléchargement des modèles |

> Le `.env` est exclu de Git via `.gitignore`. Seul `.env.example` (sans secret) doit être versionné.

### Option B – Variable d'environnement persistante

Dans PowerShell :

```powershell
[Environment]::SetEnvironmentVariable("HF_TOKEN", "hf_votre_token", "User")
```

Fermez puis rouvrez le terminal (et VS Code) pour que la variable soit prise en compte. Pour vérifier :

```powershell
$env:HF_TOKEN
```

### Option C – Variable pour la session en cours uniquement

```powershell
$env:HF_TOKEN = "hf_votre_token"
```

La variable est perdue à la fermeture du terminal.

### Option D – Connexion via la CLI Hugging Face

Le token est alors stocké dans le cache Hugging Face de l'utilisateur :

```powershell
.\.venv\Scripts\Activate.ps1
huggingface-cli login
```

Collez le token lorsqu'il est demandé (il ne s'affiche pas à l'écran).

### Option E – En argument de la commande

```powershell
transcribe reunion.m4a -d --hf-token hf_votre_token
```

> À éviter au quotidien : le token reste dans l'historique PowerShell.

## 5. Vérifier

```powershell
.\.venv\Scripts\Activate.ps1
transcribe reunion.m4a -l fr -d
```

Au premier lancement, les modèles sont téléchargés dans `%USERPROFILE%\.cache\huggingface`. Les lancements suivants n'ont plus besoin d'Internet.

## Dépannage

| Message | Cause probable | Solution |
|---|---|---|
| `Impossible de charger 'pyannote/...'` | Conditions non acceptées ou token absent | Refaire les étapes 2 à 4 |
| `401 Unauthorized` | Token invalide ou révoqué | Générer un nouveau token |
| `403 Forbidden` / `gated repo` | Conditions non acceptées sur l'un des modèles | Accepter les conditions sur **les deux** pages de l'étape 2 |
| Erreur SSL (`CERTIFICATE_VERIFY_FAILED`) | Proxy d'entreprise qui inspecte le HTTPS | Géré automatiquement via le magasin de certificats Windows (`truststore`). Sinon, définir `HTTPS_PROXY` |
| `Diarisation indisponible` | Dépendance non installée | `pip install -e ".[diarization]"` |

## Sécurité

- Le token est **personnel** : ne le partagez pas et ne le versionnez jamais (pas de token en dur dans le code ni dans un fichier suivi par Git).
- Un token **Read** suffit ; n'accordez pas de droits en écriture.
- En cas de fuite, révoquez-le immédiatement sur <https://huggingface.co/settings/tokens>.
